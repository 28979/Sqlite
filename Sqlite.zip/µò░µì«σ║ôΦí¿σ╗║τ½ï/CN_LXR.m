//
//  CN_LXR.m
//  CNApp
//
//  Created by LiuWF on 2017/6/1.
//  Copyright © 2017年 深圳市才牛网络技术有限公司. All rights reserved.
//

#import "CN_LXR.h"

@implementation CN_LXR


-(id)init
{
    if ( self = [super init] )
    {
        _guid=[Utils stringWithGUID];
        /**添加时间*/
        _addtime=[Utils FromatDateForDate];
        /**是否删除*/
        _isdel=0;
        /**头像，未用*/
        _pic=@"";
        /**权限，未用*/
        _qx=@"";
        /**备注*/
        _u_des=@"";
        /**姓名*/
        _u_name=@"";
        /**名片 未用*/
        _u_pic=@"";
        /**电话*/
        _u_tel=@"";
        /**单位*/
        _u_work=@"";
        /**职务*/
        _u_zw=@"";
        /**添加uid*/
        _uid=@"";
        /**是否更新*/
        _isup=0;
        /**是否已上传到服务器*/
        _isToServer=0;
    }
    return self;
}





- (instancetype)initWithDic:(NSDictionary *)dic
{
    self = [super init];
    if (self) {
        _guid=dic[@"id"];
        _isdel=[dic[@"isdel"] intValue];
        _uid=dic[@"uid"];//添加人
        //添加时间
        _addtime=[dic[@"addtime"] longLongValue];
        _qx=dic[@"qx"];
        _isToServer=1;
        _isup=0;
        _pic=dic[@"pic"];
        _u_des=dic[@"u_des"];
        _u_pic=dic[@"u_pic"];
        _u_name=dic[@"u_name"];
         _u_tel=dic[@"u_tel"];
        _u_work=dic[@"u_work"];
        _u_zw=dic[@"u_zw"];
    }
    return self;
}

+ (instancetype)WithDic:(NSDictionary *)dic
{
    return [[CN_LXR alloc] initWithDic:dic];
}

+ (NSArray *)WithArray:(NSArray *)array
{
    NSMutableArray *mArr = [NSMutableArray array];
    for (NSDictionary *dic in array) {
        CN_LXR *myobj = [CN_LXR WithDic:dic];
        [mArr addObject:myobj];
    }
    
    return mArr;
    
}

+(NSString *)JsonArrStr:(NSMutableArray *)arr
{
    NSMutableArray *dbarr=[[NSMutableArray alloc] init];
    for(int i=0;i<arr.count;i++)
    {
        CN_LXR *myobj =arr[i];
        [dbarr addObject:myobj.ToDic];
    }
    return [Utils getjsonStr:dbarr];
}

/**生产对像的JSON*/
-(NSString *)description{
    
    return [Utils getjsonStr:[self ToDic]];
}

-(NSDictionary *)ToDic
{
    NSDictionary *dic=@{
                        @"id":_guid,
                        @"isdel":[NSString stringWithFormat:@"%d",_isdel],
                        @"uid":_uid,
                        @"addtime":[NSString stringWithFormat:@"/Date(%ld)/",_addtime],
                        @"qx":_qx,
                        @"pic":_pic,
                        @"u_des":_u_des,
                        @"u_pic":_u_pic,
                        @"u_name":_u_name,
                        @"u_tel":_u_tel,
                        @"u_work":_u_work,
                        @"u_zw":_u_zw
                        };
    return dic;
}

@end
