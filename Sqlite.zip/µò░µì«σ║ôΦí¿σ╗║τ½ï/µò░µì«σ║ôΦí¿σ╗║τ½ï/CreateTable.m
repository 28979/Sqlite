//
//  CreateTable.m
//  LiuWFDB
//
//  Created by apple on 16/12/23.
//  Copyright © 2016年 Richard Liu. All rights reserved.
//

#import "CreateTable.h"
#import "DBSql.h"

#import "YWAddressModel.h"

@implementation CreateTable

-(void)createTable{
    //==创建所需要的表================================
    DBSql *dosql=[DBSql defaultManger];
    BOOL crok=[dosql createTabel:[YWAddressModel class]];
    if(crok)
    {
        NSLog(@"Crate Table anli ok!");
    }
    
   }

@end
