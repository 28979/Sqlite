//
//  CreateTable.h
//  LiuWFDB
//
//  Created by apple on 16/12/23.
//  Copyright © 2016年 Richard Liu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CreateTable : NSObject

-(void)createTable;

@end
