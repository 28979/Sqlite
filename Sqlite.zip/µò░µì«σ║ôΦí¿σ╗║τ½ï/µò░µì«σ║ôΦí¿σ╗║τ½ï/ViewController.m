//
//  ViewController.m
//  数据库表建立
//
//  Created by 赵士军 on 2017/3/2.
//  Copyright © 2017年 赵士军. All rights reserved.
//

#import "ViewController.h"
#import "CreateTable.h"
#import "YWAddressModel.h"
#import "DBSql.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
     [[CreateTable alloc]createTable];
    
    NSString *jsonPath = [[NSBundle mainBundle] pathForResource:@"Cities" ofType:@"json"];
    NSData *data=[NSData dataWithContentsOfFile:jsonPath];
    NSError *error;
    NSArray * jsonObjectArray =[NSJSONSerialization JSONObjectWithData:data
                                                               options:kNilOptions
                                                                 error:&error];
    NSMutableArray*datas=[[NSMutableArray alloc]init];
    for (NSDictionary * dict in jsonObjectArray) {
        YWAddressModel * item = [[YWAddressModel alloc] initWithDict:dict];
        item.guid=[self stringWithGUID];
        [datas addObject:item];
    }
    
    DBSql*_dbsql=[[DBSql alloc]init];
    [_dbsql insertArray:datas ];
}
//获取GUID
-(NSString*) stringWithGUID {
    CFUUIDRef    uuidObj = CFUUIDCreate(nil);//create a new UUID
    //get the string representation of the UUID
    NSString    *uuidString = (NSString*)CFBridgingRelease(CFUUIDCreateString(nil, uuidObj)) ;
    CFRelease(uuidObj);
    
    return uuidString;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
