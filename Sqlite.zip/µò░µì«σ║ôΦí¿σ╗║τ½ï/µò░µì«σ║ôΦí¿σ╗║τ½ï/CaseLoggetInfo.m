//
//  CaseLoggetInfo.m
//  LiuWFDB
//
//  Created by liuwf on 2016/11/28.
//  Copyright © 2016年 Richard Liu. All rights reserved.
//

#import "CaseLoggetInfo.h"

#import "fun_str.h"
@implementation CaseLoggetInfo
-(id)init
{
    if ( self = [super init] )
    {
        self.id=0;
        self.anid=0;
        /**案源*/
        self.casename=@"";
        self.addtime=(NSDate *)[fun_str GetDateTime:@"yyyy-MM-dd HH:mm:ss"];
        self.yuejianTime=(NSDate *)[fun_str GetDateTime:@"yyyy-MM-dd HH:mm:ss"];
        self.casetype=@"";
        self.formuserName=@"";
        self.weituoName=@"";
        self.anyuanId=0;
        self.tephone=@"";
        self.dangshirenName=@"";
        self.weituoConnectName=@"";
        
        self.teamknowPath=@"";
        self.jiedaiLS=@"";
        self.gengzongLS=@"";
        self.haveCasePerson=@"";
        //
        self.isWT=0;
        self.isFWFA=0;
        self.isDLJZ=0;
        self.isDYYS=0;
        self.isDLFFQ=0;
        self.isQWZGG=0;
        self.casenumType=0;
        self.nowCase=@"";
        self.isPB=0;
        self.dsrGYTime=(NSDate *)[fun_str GetDateTime:@"yyyy-MM-dd HH:mm:ss"];
        self.dsrGYPlace=@"";
        self.isLSJR=0;
        self.isAJCL=0;
        self.sqzbqkType=@"";
        self.casePassContent=@"";
        self.isToAJ=0;
        self.isdel=0;
        self.isup=0;
        self.uid=@"";
        self.isToRight=0;
        self.caseSuoshu=0;
        self.addDangshiren=@"";
        self.daili=@"";
        
        
        
    }
    return self;
}

@end
