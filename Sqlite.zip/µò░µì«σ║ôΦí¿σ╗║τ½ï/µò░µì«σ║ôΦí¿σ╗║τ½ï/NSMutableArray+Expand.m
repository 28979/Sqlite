//
//  NSMutableArray+Expand.m
//  ModelToJson
//
//  Created by cn on 2019/10/27.
//  Copyright © 2019年 sunyuqiang. All rights reserved.
//

#import "NSMutableArray+Expand.h"

@implementation NSMutableArray (Expand)

- (NSString *)description
{
    NSMutableString *result = [NSMutableString string];
    [result appendString:@"["];
    for (int i=0; i<self.count; i++) {
        [result appendString:[[self objectAtIndex:i] description]];
        if(i< (int)self.count-1){
            [result appendString:@","];
        }
    }
    [result appendString:@"]"];
    return result;
}

-(NSString*)toString{
    NSMutableString *result = [NSMutableString string];
    for (int i=0; i<self.count; i++) {
        
        [result appendString:[[self objectAtIndex:i] description]];
        if(i<(int)self.count-1){
            [result appendString:@","];
        }
    }
    return result;
}

@end
