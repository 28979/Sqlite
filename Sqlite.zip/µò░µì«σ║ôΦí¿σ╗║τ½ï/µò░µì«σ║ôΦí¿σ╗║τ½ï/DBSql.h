//
//  DBSql.h
//  Test
//
//  Created by 2101b on 15/12/27.
//  Copyright © 2015年 Richard Liu. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface DBSql : NSObject


+(instancetype)defaultManger;

/**
  *  使用实体类型进行自动建表
  *
  *  @param modelType 实体类型 用于自动检索实体的属性
  *
  *  @return 返回bool
  */
-(BOOL)createTabel:(Class)modelType;
/**
  *  增删改语句通用执行方法
  *
  *  @param sql 传入sql语句
  *
  *  @return 返回bool值
  */
-(BOOL)execute:(NSString*)sql;

/**
  *  执行查询
  *
 
  *  @return 返回 数组<字典> 字典的键与数据库字段名相同
  */
-(NSMutableArray *)executeQuery:(Class)cls :(NSString *)sql;

/**
  *  得到一条记录的实体
  *
  *  @sql 为指领
  *
  *  @return 返回一个实体
  */
-(id)executeQueryOne:(Class)cls :(NSString *)sql;

/**
  *  插入一个实体对象到某一张表
  *
  *  model     实体对象
  *
  *  @return 返回bool值
  */
-(BOOL)insertModel:(id)model;
/**
  *  更新一个实体对象到某一张表
  *
  *
  *  @return 返回bool值
  */
-(BOOL)UpdateModel:(id)model;
//tag=41;更新旧版本
-(BOOL)UpdateOldModel:(id)model;


/**
  *  执行sql,返回记录数
  *
  *
  *  @return 返回bool值
  */
-(int)executeCount:(NSString *)sql;

//tag=6;批量插入
-(BOOL)insertArray:(NSArray*)array;

//tag=7;批量执行sql
-(BOOL)executeSqlArray:(NSArray*)array;

-(BOOL)insertOrReplaceModel:(id)model;

-(NSMutableArray *)executeNOOpenQuery:(Class)cls :(NSString *)sql;
-(id)executeNOOpenQueryOne:(Class)cls :(NSString *)sql;

-(BOOL)open;
-(BOOL)close;

-(NSArray *)allPropertyNameInClass:(Class)cls;
@end

