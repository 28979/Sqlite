//
//  fun_str.m
//  LiuWFDB
//
//  Created by LiuWF on 15/12/27.
//  Copyright © 2015年 Richard Liu. All rights reserved.
//

#import "fun_str.h"

@implementation fun_str

/**伤残赔偿计算*/
+(float)jiaoton_soncan_money:(int)nl joinmoney:(float)joinm denji:(int) dj
{
    
    float zm=0;
    /**伤残系统值*/
    float xsm=[self soncan_xisuo:dj];
    if(nl<60)
    {
        zm=20*joinm *xsm;
    }
    else if(nl>59 && nl<75)
    {
        zm=joinm *(20-(nl-60)) *xsm;
    }
    else
    {
        //75以上
        zm=joinm *(11-dj)*0.5;
    }
    return zm;
}

/**死忘赔偿计算*/
+(float)jiaoton_siwan_money:(int)nl joinmoney:(float)joinm
{
    float zm=0;
    if(nl<60)
    {
        zm=20*joinm;
    }
    else if(nl>59 && nl<75)
    {
        zm=joinm *(20-(nl-60));
    }
    else
    {
        //75以上
        zm=joinm *5;
    }
    return zm;
}

/**死忘抚养计算*/
+(float)jiaoton_siwan_fuyan_money:(int)nl joinmoney:(float)joinm renshu:(int) rs
{
    float zm=0;
    if(nl<18)
    {
        zm=joinm*(18-nl)/rs;
    }
    else if(nl<60)
    {
        zm=20*joinm/rs;
    }
    else if(nl>59 && nl<75)
    {
        zm=joinm *(20-(nl-60))/rs;
    }
    else
    {
        //75以上
        zm=joinm *5/rs;
    }
    return zm;
}

/**伤残抚养计算*/
+(float)jiaoton_soncan_fuyan_money:(int)nl joinmoney:(float)joinm denji:(int) dj renshu:(int) rs
{
    float zm=0;
    /**伤残系统值*/
    float xsm=[self soncan_xisuo:dj];
    
    if(nl<18)
    {
        zm=joinm*(18-nl)*xsm/rs;
    }
    else if(nl<60)
    {
        zm=20*joinm*xsm/rs;
    }
    else if(nl>59 && nl<75)
    {
        zm=joinm *(20-(nl-60))*xsm/rs;
    }
    else
    {
        //75以上
        zm=joinm *5*xsm/rs;
    }
    return zm;
}

/**伤残等级对应的赔偿系数*/
+(float)soncan_xisuo:(int)dj
{
    float xs=0;
    switch (dj) {
        case 1:
            xs=1;
            break;
        case 2:
            xs=0.9;
            break;
        case 3:
            xs=0.8;
            break;
        case 4:
            xs=0.7;
            break;
        case 5:
            xs=0.6;
            break;
        case 6:
            xs=0.5;
            break;
        case 7:
            xs=0.4;
            break;
        case 8:
            xs=0.3;
            break;
        case 9:
            xs=0.2;
            break;
        case 10:
            xs=0.1;
            break;
        default:
            break;
    }
    return xs;
}


//计算律师费用
+(NSString *)get_ls_money:(NSString *)info :(NSString *)mon
{
    //0★10★800●0.05☆10★50★0.04☆50★100★0.03☆100★500★0.02☆500★1000★0.01☆1000★0★0.005
    if([info isEqualToString:@""] || [mon isEqualToString:@""])
    {
        return @"";
    }
    float mym=[self ToFloat:mon];
    
    float v1=0;
    float v2=0;
    float true_m=[self ToFloat:mon]; //超出部分用这个乘利率
    float temp_k2=0;
    NSArray *temp=[self Split:info :@"☆"];
    for (int i=0; i<temp.count; i++) {
        NSArray *temp1=[self Split:temp[i] :@"★"];
        
        int k1=[self ToInt32:[NSString stringWithFormat:@"%@0000",temp1[0]]];
        int k2=[self ToInt32:[NSString stringWithFormat:@"%@0000",temp1[1]]];
        if(mym<=k2 || k2==0)
        {
            
            true_m-=temp_k2;
            
            //在这个范围内
            if([self IndexOf:temp1[2] :@"●"]>-1)
            {
                //有双利率值
                NSArray *temp2=[self Split:temp1[2] :@"●"];
                if([self IndexOf:temp2[0] :@"."]==-1 && [self IndexOf:temp2[1] :@"."]==-1)
                {
                    //两个都是非小数
                    v1=[self ToFloat:temp2[0]];
                    v2=[self ToInt32:temp2[1]];
                }
                else if([self IndexOf:temp2[0] :@"."]==-1 && [self IndexOf:temp2[1] :@"."]>-1)
                {
                    //前面是整数，后面是小数
                    float okvm= true_m*[self ToFloat:temp2[1]];
                    float ttxb=[self ToFloat:temp2[0]];
                    if(okvm>ttxb)
                    {
                        v1=okvm;
                        v2=okvm;
                    }
                    else
                    {
                        v1=ttxb;
                        v2=ttxb;
                    }
                }
                else
                {
                    //两个都是小数
                    float okvm= true_m*[self ToFloat:temp2[0]];
                    v1+=okvm;
                    okvm= true_m*[self ToFloat:temp2[1]];
                    v2+=okvm;
                }
            }
            else
            {
                //单利率值
                if([self IndexOf:temp1[2] :@"."]==-1)
                {
                    v1+=[self ToInt32:temp1[2]];
                    v2+=[self ToInt32:temp1[2]];
                }
                else
                {
                    float okvm= true_m*[self ToFloat:temp1[2]];
                    v1+=okvm;
                    v2+=okvm;
                }
            }
            
            
            break;
        }
        else
        {
            //超过了这个范围
            if([self IndexOf:temp1[2] :@"●"]>-1)
            {
                //有双利率值
                NSArray *temp2=[self Split:temp1[2] :@"●"];
                if([self IndexOf:temp2[0] :@"."]==-1 && [self IndexOf:temp2[1] :@"."]==-1)
                {
                    //两个都是非小数
                    v1=[self ToFloat:temp2[0]];
                    v2=[self ToInt32:temp2[1]];
                }
                else if([self IndexOf:temp2[0] :@"."]==-1 && [self IndexOf:temp2[1] :@"."]>-1)
                {
                    //前面是整数，后面是小数
                    float okvm= k2*[self ToFloat:temp2[1]];
                    float ttxb=[self ToFloat:temp2[0]];
                    if(okvm>ttxb)
                    {
                        v1=okvm;
                        v2=okvm;
                    }
                    else
                    {
                        v1=ttxb;
                        v2=ttxb;
                    }
                }
                else
                {
                    //两个都是小数
                    float okvm= (k2-k1)*[self ToFloat:temp2[0]];
                    v1+=okvm;
                    okvm= (k2-k1)*[self ToFloat:temp2[1]];
                    v2+=okvm;
                    
                }
            }
            else
            {
                //单利率值
                if([self IndexOf:temp1[2] :@"."]==-1)
                {
                    v1+=[self ToInt32:temp1[2]];
                    v2+=[self ToInt32:temp1[2]];
                }
                else
                {
                    float okvm= (k2-k1)*[self ToFloat:temp1[2]];
                    v1+=okvm;
                    v2+=okvm;
                }
                
                
            }
            
            temp_k2=k2;
        }
        
    }
    NSString *tx1=[NSString stringWithFormat:@"%f",v1];
    NSString *tx2=[NSString stringWithFormat:@"%f",v2];
    NSArray *tembt=[self Split:tx1 :@"."];
    tx1=tembt[0];
    tembt=[self Split:tx2 :@"."];
    tx2=tembt[0];
    if([tx1 isEqualToString:tx2])
    {
        return [NSString stringWithFormat:@"律师费：%@",tx1];
    }
    else
    {
        return [NSString stringWithFormat:@"律师费：%@~%@",tx1,tx2];
    }
    
}

////得到显示的高度
//+(CGSize)getLabelheight:(UILabel *)dislable width:(float)w height:(float)h
//{
//    CGSize size = CGSizeMake(w, h);
//    CGSize labelSize = [dislable.text boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : dislable.font} context:nil].size;
//    return labelSize;
//}
//
////得到显示的高度
//+(CGSize)getTextFixeheight:(UITextField *)dislable width:(float)w height:(float)h
//{
//    CGSize size = CGSizeMake(w, h);
//    CGSize labelSize = [dislable.text boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : dislable.font} context:nil].size;
//    return labelSize;
//}
//
////得到显示的高度
//+(CGSize)getTextViewheight:(UITextView *)dislable width:(float)w height:(float)h
//{
//    CGSize size = CGSizeMake(w, h);
//    CGSize labelSize = [dislable.text boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : dislable.font} context:nil].size;
//    return labelSize;
//}
//
//+ (UIColor *)getcolor:(NSString *)inColorString
//{
//    UIColor *result = nil;
//    unsigned int colorCode = 0;
//    unsigned char redByte, greenByte, blueByte;
//    
//    if (nil != inColorString)
//    {
//        NSScanner *scanner = [NSScanner scannerWithString:inColorString];
//        (void) [scanner scanHexInt:&colorCode]; // ignore error
//    }
//    redByte = (unsigned char) (colorCode >> 16);
//    greenByte = (unsigned char) (colorCode >> 8);
//    blueByte = (unsigned char) (colorCode); // masks off high bits
//    result = [UIColor
//              colorWithRed: (float)redByte / 0xff
//              green: (float)greenByte/ 0xff
//              blue: (float)blueByte / 0xff
//              alpha:1.0];
//    return result;
//}
//

//替换
+(NSString *)Replace:(NSString *)str :(NSString *)oldstr :(NSString *)newstr
{
    if([str isEqual:nil] || [oldstr isEqual:nil] || [newstr isEqual:nil])
    {
        return  @"";
    }
    return [str stringByReplacingOccurrencesOfString:oldstr withString:newstr];
}


//分隔字符
+(NSArray *)Split :(NSString *)str :(NSString *)plstr
{
    return [str componentsSeparatedByString:plstr];
}
//字串截取指定长度
+(NSString *)Substring :(NSString *)str :(int)sindex :(int)eindex
{
    return [str substringWithRange:NSMakeRange(sindex,eindex)];
}
//转成float　%.0f 可以输出整数
+(float)ToFloat:(NSString *)str
{
    id result;
    NSNumberFormatter *f = [[NSNumberFormatter alloc] init];
    result=[f numberFromString:str];
    if(!(result))
    {
        result=str;
    }
    //[f release];
    return [result floatValue];
    
}
//转成int
+(int)ToInt32:(NSString *)str
{
    id result;
    NSNumberFormatter *f = [[NSNumberFormatter alloc] init];
    result=[f numberFromString:str];
    if(!(result))
    {
        result=str;
    }
   
    return (int)[result integerValue];
}

//检测ostr中是否包含sstr
+(int)IndexOf:(NSString *)ostr :(NSString *)sstr
{
    NSRange range = [ostr rangeOfString:sstr];
    int temp= (int)range.location;
    if(temp>[ostr length])
    {
        return -1;
    }
    else
    {
        return temp;
    }
}

////MD5 加密
//+(NSString *)MD5:(NSString*)str
//{
//    const char *original_str = [str UTF8String];
//    unsigned char result[CC_MD5_DIGEST_LENGTH];
//    CC_MD5(original_str, (int)strlen(original_str), result);
//    NSMutableString *hash = [NSMutableString string];
//    for (int i = 0; i < 16; i++)
//        [hash appendFormat:@"%02X", result[i]];
//    return [[hash lowercaseString] uppercaseString];
//    
//    
//}
//NSData 转到 NsString
+(NSString *)NSDataToNSstring:(NSData *)Data
{
    return [[NSString alloc] initWithData:Data encoding:NSUnicodeStringEncoding];
}


//得到当前的时间 str=yyyy-MM-dd HH:mm:ss
+(NSString *)GetDateTime:(NSString *)str
{
    NSString* date;
    NSDate *today = [NSDate date];
    NSDateFormatter* formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:str];
    date = [formatter stringFromDate:today];
    return date;
}

//得到随机值
+(NSString *)GetRadStr:(int)_maxid
{
    int _temp=arc4random()% _maxid;
    return [NSString stringWithFormat:@"%d",_temp];
}


+(NSString *)GetRadStr_count:(int)_maxid
{
    NSString *okdes=@"";
    for(int i=0;i<_maxid;i++)
    {
        int _temp=arc4random()% 9;
        okdes=[NSString stringWithFormat:@"%@%d",okdes,_temp];
    }
    return okdes;
}

//字串转成日期
+(NSDate *)StringToDate:(NSString *)datastr :(NSString *)frmatstr siqi:(int)issq
{
    NSDateFormatter * formatter = [[NSDateFormatter alloc] init];
    //[formatter setDateFormat:@"yyyy-MM-dd HH:mm +0800"]; //设置时区
    [formatter setDateFormat: frmatstr];
    
    NSDate * temd= [formatter dateFromString :datastr];
    if(issq==0)
    {
        return  temd;
    }
    else
    {
        NSDate * oktime=[NSDate dateWithTimeInterval:28800 sinceDate:temd]; //加8个小时时区
        return oktime;
    }
}

//两个日期的相差天数 一定不能有时分
+(int)DateIsDay:(NSString *)t1 :(NSString *)t2
{
    if([self IndexOf:t1 :@" "]>-1)
    {
        NSArray *temb=[self Split:t1 :@" "];
        t1=temb[0];
    }
    if([self IndexOf:t2 :@" "]>-1)
    {
        NSArray *temb=[self Split:t2 :@" "];
        t2=temb[0];
    }
    
    NSDate *now=[self StringToDate:t2 :@"yyyy-MM-dd" siqi:0];
    //实例化一个NSDateFormatter对象
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    //设定时间格式,这里可以设置成自己需要的格式
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSDate *date1=nil;
    date1 =[dateFormatter dateFromString:t1];
    
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    unsigned int unitFlags = NSDayCalendarUnit;
    NSDateComponents *comps = [gregorian components:unitFlags fromDate:date1  toDate:now  options:0];
    int days = (int)[comps day];
    return  days;
}
//一个日期是星期几  一定不能有时分
+(NSString *)getWeekdayFromDate:(NSString *)str
{
    NSDate *nowDate=[self StringToDate:str :@"yyyy-MM-dd" siqi:0];
    //NSDate *nowDate = [NSDate date];    //时间
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *comps;
    comps = [calendar components:(NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit) fromDate:nowDate];
    //int nowYear = [comps year];
    //int nowMonth = [comps month];
    //int nowDay = [comps day];
    int nowWeek = (int)[comps weekday];
    NSString *weekStr = [[NSString alloc] init];
    switch (nowWeek) {
        case 1:
            weekStr = @"星期天";
            break;
        case 2:
            weekStr = @"星期一";
            break;
        case 3:
            weekStr = @"星期二";
            break;
        case 4:
            weekStr = @"星期三";
            break;
        case 5:
            weekStr = @"星期四";
            break;
        case 6:
            weekStr = @"星期五";
            break;
        case 7:
            weekStr = @"星期六";
            break;
            
        default:
            break;
    }
    return  weekStr;
}


//得到一个日期添加多少时，或多少分后的一个新日期
+(NSDate *)GetAddTime:(NSString *) time addHH:(int) addhh addmm:(int)adm
{
    NSDate *today=[self StringToDate:time :@"yyyy-MM-dd HH:mm" siqi:1];
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
    [offsetComponents setHour:+addhh];
    [offsetComponents setMinute:+adm];
    // Calculate when, according to Tom Lehrer, World War III will end
    NSDate *endOfWorldWar3 = [gregorian dateByAddingComponents:offsetComponents toDate:today options:0];
    return  endOfWorldWar3;
}

//得到一个日期添加多少时，或多少分后的一个新日期
+(NSDate *)GetAddTime:(NSString *) time addHH:(int) addhh addmm:(int)adm addss:(int) ads
{
    NSDate *today=[self StringToDate:time :@"yyyy-MM-dd HH:mm:ss" siqi:1];

    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
    [offsetComponents setHour:+addhh];
    [offsetComponents setMinute:+adm];
    [offsetComponents setSecond:ads];
    // Calculate when, according to Tom Lehrer, World War III will end
    NSDate *endOfWorldWar3 = [gregorian dateByAddingComponents:offsetComponents toDate:today options:0];
    return  endOfWorldWar3;
}

//时间日期转成字串
+(NSString *)NsDateToString:(NSDate *)sdate format:(NSString *)formatv
{
    NSDateFormatter* dateFormat = [[NSDateFormatter alloc] init];
    //实例化一个NSDateFormatter对象
    [dateFormat setDateFormat:formatv];//设定时间格式
    NSDate * oktime=[NSDate dateWithTimeInterval:-28800 sinceDate:sdate];
    //[dateFormat release];
    return [dateFormat stringFromDate:oktime];
    
}


//数字转成大写货币
+(NSString*)money_ToString:(NSString*)numstr{
    
    double numberals=[numstr doubleValue];
    NSArray *numberchar = @[@"零",@"壹",@"贰",@"叁",@"肆",@"伍",@"陆",@"柒",@"捌",@"玖"];
    NSArray *inunitchar = @[@"",@"拾",@"佰",@"仟"];
    NSArray *unitname = @[@"",@"万",@"亿",@"万亿"];
    //金额乘以100转换成字符串（去除圆角分数值）
    NSString *valstr=[NSString stringWithFormat:@"%.2f",numberals];
    NSString *prefix;
    NSString *suffix;
    if (valstr.length<=2) {
        prefix=@"零元";
        if (valstr.length==0) {
            suffix=@"零角零分";
        }
        else if (valstr.length==1)
        {
            suffix=[NSString stringWithFormat:@"%@分",[numberchar objectAtIndex:[valstr intValue]]];
        }
        else
        {
            NSString *head=[valstr substringToIndex:1];
            NSString *foot=[valstr substringFromIndex:1];
            suffix=[NSString stringWithFormat:@"%@角%@分",[numberchar objectAtIndex:[head intValue]],[numberchar objectAtIndex:[foot intValue]]];
        }
    }
    else
    {
        prefix=@"";
        suffix=@"";
        int flag=(int)valstr.length-2;
        NSString *head=[valstr substringToIndex:flag-1];
        NSString *foot=[valstr substringFromIndex:flag];
        if (head.length>13) {
            return@"数值太大（最大支持13位整数），无法处理";
        }
        //处理整数部分
        NSMutableArray *ch=[[NSMutableArray alloc]init];
        for (int i = 0; i < head.length; i++) {
            NSString * str=[NSString stringWithFormat:@"%x",[head characterAtIndex:i]-'0'];
            [ch addObject:str];
        }
        int zeronum=0;
        
        for (int i=0; i<ch.count; i++) {
            int index=(ch.count -i-1)%4;//取段内位置
            int indexloc=(int)(ch.count -i-1)/4;//取段位置
            if ([[ch objectAtIndex:i]isEqualToString:@"0"]) {
                zeronum++;
            }
            else
            {
                if (zeronum!=0) {
                    if (index!=3) {
                        prefix=[prefix stringByAppendingString:@"零"];
                    }
                    zeronum=0;
                }
                prefix=[prefix stringByAppendingString:[numberchar objectAtIndex:[[ch objectAtIndex:i]intValue]]];
                prefix=[prefix stringByAppendingString:[inunitchar objectAtIndex:index]];
            }
            if (index ==0 && zeronum<4) {
                prefix=[prefix stringByAppendingString:[unitname objectAtIndex:indexloc]];
            }
        }
        prefix =[prefix stringByAppendingString:@"元"];
        //处理小数位
        if ([foot isEqualToString:@"00"]) {
            suffix =[suffix stringByAppendingString:@"整"];
        }
        else if ([foot hasPrefix:@"0"])
        {
            NSString *footch=[NSString stringWithFormat:@"%x",[foot characterAtIndex:1]-'0'];
            suffix=[NSString stringWithFormat:@"%@分",[numberchar objectAtIndex:[footch intValue] ]];
        }else{
        
            NSArray*points=[fun_str Split:valstr :@"." ];
            if ([fun_str IndexOf:valstr :@"."]>-1) {
              
                if(points.count>1){
                    NSString *input = points[1];
                    
                    
                    NSString *first = [input substringToIndex:1];//字符串开始
                    
                    NSString *last = [input substringFromIndex:input.length-1];//字符串结尾
                    

                    if([last isEqualToString:@"0"]){
                        suffix=[NSString stringWithFormat:@"%@角",[numberchar objectAtIndex:[first intValue]]];
                        
                    }else{
                           
                 suffix=[NSString stringWithFormat:@"%@角%@分",[numberchar objectAtIndex:[first intValue]],[numberchar objectAtIndex:[last intValue]]];
                    }
                }
            }
           

//            NSString *head=[valstr substringToIndex:1];
//            NSString *foot=[valstr substringFromIndex:1];
//            
//            suffix=[NSString stringWithFormat:@"%@角%@分",[numberchar objectAtIndex:[head intValue]],[numberchar objectAtIndex:[foot intValue]]];
            
        }
        
    }
    return [prefix stringByAppendingString:suffix];
}

////得到当前屏的分变
//+(CGSize) screenSize
//{
//    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
//    CGSize size = [UIScreen mainScreen].bounds.size;
//    UIApplication *application = [UIApplication sharedApplication];
//    if (UIInterfaceOrientationIsLandscape(orientation))
//    {
//        size = CGSizeMake(size.height, size.width);
//    }
//    if (application.statusBarHidden == NO)
//    {
//        size.height -= MIN(application.statusBarFrame.size.width, application.statusBarFrame.size.height);
//    }
//    return size;
//}
//

//比较两个日期谁大
+(int)compareOneDay:(NSDate *)oneDay withAnotherDay:(NSDate *)anotherDay
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd-MM-yyyy"];
    NSString *oneDayStr = [dateFormatter stringFromDate:oneDay];
    NSString *anotherDayStr = [dateFormatter stringFromDate:anotherDay];
    NSDate *dateA = [dateFormatter dateFromString:oneDayStr];
    NSDate *dateB = [dateFormatter dateFromString:anotherDayStr];
    NSComparisonResult result = [dateA compare:dateB];
    //NSLog(@"date1 : %@, date2 : %@", oneDay, anotherDay);
    if (result == NSOrderedDescending) {
        //NSLog(@"Date1  is in the future");
        return 1;
    }
    else if (result == NSOrderedAscending){
        //NSLog(@"Date1 is in the past");
        return -1;
    }
    //NSLog(@"Both dates are the same");
    return 0;
    
}

//字串转int
+(int)StringToInt:(NSString *)val
{
    NSScanner *scanner=[NSScanner scannerWithString:val];
    int temp;
    //[scanner scanFloat:&temp];
    [scanner scanInt:&temp];
    return temp;
}

//字串转int
+(float)StringToFloat:(NSString *)val
{
    NSScanner *scanner=[NSScanner scannerWithString:val];
    float temp;
    [scanner scanFloat:&temp];
    return temp;
}


@end
