//
//  fun_str.h
//  LiuWFDB
//
//  Created by LiuWF on 15/12/27.
//  Copyright © 2015年 Richard Liu. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CommonCrypto/CommonDigest.h>
#import "DBSql.h"

@interface fun_str : NSObject
/**计算律师费*/
/**随机数*/
+(NSString *)GetRadStr_count:(int)_maxid;

+(NSString *)get_ls_money:(NSString *)info :(NSString *)mon;
/**伤残赔偿计算*/
+(float)jiaoton_soncan_money:(int)nl joinmoney:(float)joinm denji:(int) dj;
/**死忘赔偿计算*/
+(float)jiaoton_siwan_money:(int)nl joinmoney:(float)joinm;
/**死忘抚养计算*/
+(float)jiaoton_siwan_fuyan_money:(int)nl joinmoney:(float)joinm renshu:(int) rs;
/**伤残抚养计算*/
+(float)jiaoton_soncan_fuyan_money:(int)nl joinmoney:(float)joinm denji:(int) dj renshu:(int) rs;
///** 得到标签的高度 */
//+(CGSize)getLabelheight:(UILabel *)dislable width:(float)w height:(float)h;
///**得到文件框的高度*/
//+(CGSize)getTextFixeheight:(UITextField *)dislable width:(float)w height:(float)h;
///**得到显示的高度*/
//+(CGSize)getTextViewheight:(UITextView *)dislable width:(float)w height:(float)h;
///** 系统色值，通过3位ＧＲＢ色 */
//+ (UIColor *)getcolor:(NSString *)inColorString;
/** 替换 */
+(NSString *)Replace :(NSString *)str :(NSString *)oldstr :(NSString *)newstr;
/**分隔*/
+(NSArray *)Split:(NSString *)str :(NSString *)plstr;
/** 取指定长度*/
+(NSString *)Substring:(NSString *)str :(int)sindex :(int)eindex;

/**字串转浮点 */
+(float)ToFloat:(NSString *)str;

/**字串转整数*/
+(int)ToInt32:(NSString *)str;

/**是否包含 */
+(int)IndexOf:(NSString *)ostr :(NSString *)sstr;


/**MD5 */
+(NSString *)MD5:(NSString*)str;

/** NSData 转字串 */
+(NSString *)NSDataToNSstring:(NSData *)Data;

/** 得到时间字串*/
+(NSString *)GetDateTime:(NSString *)str;

/**得到随机数 */
+(NSString *)GetRadStr:(int)_maxid;


/** 
 *字串转时间
 *datastr时间数据
 *frmtstr 格式如：yyyy-MM-dd
 * issq  是否加8小时，时区
 */

+(NSDate *)StringToDate:(NSString *)datastr :(NSString *)frmatstr siqi:(int)issq;


/**两日期相差的天数，不能有时分 */
+(int)DateIsDay:(NSString *)t1 :(NSString *)t2;

/**一个日期是星期几 不能有时分*/
+(NSString *)getWeekdayFromDate :(NSString *)str;


/**得到一个添加值的日期数 只到分*/
+(NSDate *)GetAddTime:(NSString *) time addHH:(int) addhh addmm:(int)adm;

/**得到一个添加值的日期数 到秒*/
+(NSDate *)GetAddTime:(NSString *) time addHH:(int) addhh addmm:(int)adm addss:(int) ads;

/**时间转成字串*/
+(NSString *)NsDateToString:(NSDate *)sdate format:(NSString *)formatv;

/**货币转成大写*/
+(NSString*)money_ToString:(NSString*)numstr;
//
///**得到当前屏的大屏尺寸*/
//+(CGSize) screenSize;

/** 比较两日期谁大*/
+(int)compareOneDay:(NSDate *)oneDay withAnotherDay:(NSDate *)anotherDay;

/**字串转int*/
+(int)StringToInt:(NSString *)val;

/**字串转浮点*/
+(float)StringToFloat:(NSString *)val;

@end
