//
//  CaseLoggetInfo.h
//  LiuWFDB
//
//  Created by liuwf on 2016/11/28.
//  Copyright © 2016年 Richard Liu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CaseLoggetInfo : NSObject
/**案源*/

@property (nonatomic,assign) int id;
@property (nonatomic,assign) int anyuanId;
@property (nonatomic,assign) int anid;
@property (nonatomic,strong) NSString *uid;
@property (nonatomic,strong) NSString *casename;//案件名称
@property(nonatomic,strong) NSDate *addtime;//日期
@property (nonatomic,strong) NSString *casetype;//案件类型
@property (nonatomic,assign) int casenumType;//案件类型数字
@property(nonatomic,strong) NSString *formuserName;//填表人
@property(nonatomic,strong) NSDate *yuejianTime;//约见时间
@property(nonatomic,strong) NSString *weituoName;//委托人姓名
@property (nonatomic,strong) NSString *tephone;//联系方式
@property(nonatomic,strong) NSString *dangshirenName;//当事人姓名
@property(nonatomic,strong) NSString *weituoConnectName;//与委托人关系
@property(nonatomic,strong) NSString *teamknowPath;//对团队了解途径

@property (nonatomic,strong) NSString * jiedaiLS;//接待律师
@property(nonatomic,strong) NSString *gengzongLS;//跟踪律师
@property (nonatomic,assign) int isWT;//是否委托
@property (nonatomic,assign) int isFWFA;//是否出具服务方案
@property (nonatomic,assign) int isDLJZ;//代理价值
@property (nonatomic,assign) int isDYYS;//地域因素
@property (nonatomic,assign) int isDLFFQ;//代理费分歧
@property (nonatomic,assign) int isQWZGG;//期望值过高


@property (nonatomic,strong) NSString *nowCase;//现时案件阶段
@property (nonatomic,assign) int isPB;//当事人有无批捕
@property (nonatomic,strong) NSDate *dsrGYTime;//当事人被羁押时间
@property (nonatomic,strong) NSString *dsrGYPlace;//当事人被羁押地点
@property (nonatomic,assign) int isLSJR;//有无其他律师介入
@property (nonatomic,assign) int isAJCL;//有无相关案卷材料
@property (nonatomic,strong) NSString *sqzbqkType;//接受委托手续准备情况
@property (nonatomic,strong) NSString *casePassContent;//案情经过
@property (nonatomic,assign) int isdel;//删除
@property (nonatomic,assign) int isup;//修改
@property (nonatomic,assign) int isToRight;//修改
@property (nonatomic,strong) NSString *haveCasePerson;//接案人
@property (nonatomic,assign) int  caseSuoshu;//案件所属
//
@property (nonatomic,assign) int isToAJ;//是否转案件

//添加当事人
@property (nonatomic,strong) NSString *addDangshiren;//
/**daili  Ψ ※ ●*/
@property (nonatomic,strong) NSString *daili;//
@end
