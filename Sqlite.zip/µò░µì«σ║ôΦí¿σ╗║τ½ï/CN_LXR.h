//
//  CN_LXR.h
//  CNApp
//
//  Created by LiuWF on 2017/6/1.
//  Copyright © 2017年 深圳市才牛网络技术有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
/**系统联系人*/
@interface CN_LXR : NSObject
/**主GUID*/
@property (nonatomic,strong) NSString *guid;
/**添加时间*/
@property (nonatomic,assign) long addtime;
/**是否删除*/
@property (nonatomic,assign) int isdel;
/**头像，未用*/
@property (nonatomic,strong) NSString *pic;
/**权限，未用*/
@property (nonatomic,strong) NSString *qx;
/**备注*/
@property (nonatomic,strong) NSString *u_des;
/**姓名*/
@property (nonatomic,strong) NSString *u_name;
/**名片 未用*/
@property (nonatomic,strong) NSString *u_pic;
/**电话*/
@property (nonatomic,strong) NSString *u_tel;
/**单位*/
@property (nonatomic,strong) NSString *u_work;
/**职务*/
@property (nonatomic,strong) NSString *u_zw;
/**添加uid*/
@property (nonatomic,strong) NSString *uid;
/**是否更新*/
@property (nonatomic,assign) int isup;
/**是否已上传到服务器*/
@property (nonatomic,assign) int isToServer;



+(NSArray *)WithArray:(NSArray *)array;
-(NSDictionary *)ToDic;
+(instancetype)WithDic:(NSDictionary *)dic;
+(NSString *)JsonArrStr:(NSMutableArray *)arr;
@end
